from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import os
import json
import random
from datetime import datetime
from werkzeug.utils import secure_filename
import uuid

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Data directory for JSON files
DATA_FOLDER = 'data'
PASSENGERS_FILE = os.path.join(DATA_FOLDER, 'passengers.json')
PASSENGERS_DATA_FILE = 'passengers_data.json'
COINS_FILE = os.path.join(DATA_FOLDER, 'user_coins.json')
PAYMENTS_FILE = os.path.join(DATA_FOLDER, 'payments.json')
NOTIFICATIONS_FILE = os.path.join(DATA_FOLDER, 'notifications.json')
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Create necessary directories if they don't exist
os.makedirs(DATA_FOLDER, exist_ok=True)

# Initialize JSON files if they don't exist
if not os.path.exists(PASSENGERS_FILE):
    with open(PASSENGERS_FILE, 'w') as f:
        json.dump({}, f)

if not os.path.exists(COINS_FILE):
    with open(COINS_FILE, 'w') as f:
        json.dump({}, f)

if not os.path.exists(PAYMENTS_FILE):
    with open(PAYMENTS_FILE, 'w') as f:
        json.dump([], f)

if not os.path.exists(NOTIFICATIONS_FILE):
    with open(NOTIFICATIONS_FILE, 'w') as f:
        json.dump({}, f)

# Load passenger data
def load_passengers():
    try:
        with open(PASSENGERS_FILE, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def save_passengers(passengers):
    with open(PASSENGERS_FILE, 'w') as f:
        json.dump(passengers, f, indent=4)

passengers_data = load_passengers()

# Define bus routes and fares
bus_fares = {
    ('Tupi', 'Koronadal'): 50,
    ('Koronadal', 'Tupi'): 50,
    ('Koronadal', 'Banga'): 30,
    ('Banga', 'Koronadal'): 30,
    ('Banga', 'Surallah'): 50,
    ('Surallah', 'Banga'): 50,
    ('Tupi', 'General Santos'): 120,
    ('General Santos', 'Tupi'): 120,
    ('Tupi', 'Polomolok'): 40,
    ('Polomolok', 'Tupi'): 40,
    ('Koronadal', 'Surallah'): 80,
    ('Surallah', 'Koronadal'): 80,
    ('Polomolok', 'General Santos'): 70,
    ('General Santos', 'Polomolok'): 70,
    ('Banga', 'Norala'): 45,
    ('Norala', 'Banga'): 45,
    ('Surallah', 'Tantangan'): 35,
    ('Tantangan', 'Surallah'): 35,
    ('Tboli', 'Lake Sebu'): 60,
    ('Lake Sebu', 'Tboli'): 60,
    ('Norala', 'Santo Niño'): 55,
    ('Santo Niño', 'Norala'): 55
}

# Define all buses with their types
all_buses = [
    {'bus_id': 'BUS001', 'origin': 'Tupi', 'destination': 'Koronadal', 'date': '2025-04-20', 'time': '08:00 AM', 'seats': 30, 'bus_type': 'Non-stop'},
    {'bus_id': 'BUS002', 'origin': 'Tupi', 'destination': 'General Santos', 'date': '2025-04-20', 'time': '09:30 AM', 'seats': 30, 'bus_type': 'Regular'},
    {'bus_id': 'BUS003', 'origin': 'Tupi', 'destination': 'Koronadal', 'date': '2025-04-21', 'time': '10:00 AM', 'seats': 30, 'bus_type': 'Regular'},
    {'bus_id': 'BUS004', 'origin': 'Tupi', 'destination': 'Koronadal', 'date': '2025-04-20', 'time': '01:00 PM', 'seats': 30, 'bus_type': 'Non-stop'},
    {'bus_id': 'BUS005', 'origin': 'Tupi', 'destination': 'Koronadal', 'date': '2025-04-20', 'time': '03:00 PM', 'seats': 30, 'bus_type': 'Regular'},
    {'bus_id': 'BUS006', 'origin': 'Tupi', 'destination': 'General Santos', 'date': '2025-04-21', 'time': '05:00 PM', 'seats': 30, 'bus_type': 'Non-stop'},
    {'bus_id': 'BUS007', 'origin': 'General Santos', 'destination': 'Tupi', 'date': '2025-04-20', 'time': '07:30 AM', 'seats': 30, 'bus_type': 'Non-stop'},
    {'bus_id': 'BUS008', 'origin': 'Koronadal', 'destination': 'Tupi', 'date': '2025-04-20', 'time': '11:45 AM', 'seats': 30, 'bus_type': 'Regular'},
    {'bus_id': 'BUS009', 'origin': 'General Santos', 'destination': 'Koronadal', 'date': '2025-04-21', 'time': '02:15 PM', 'seats': 30, 'bus_type': 'Non-stop'},
    {'bus_id': 'BUS010', 'origin': 'Koronadal', 'destination': 'General Santos', 'date': '2025-04-22', 'time': '04:30 PM', 'seats': 30, 'bus_type': 'Regular'}
]

# Define fixed fares for specific routes
fixed_fares = {
    ('tupi', 'surallah'): 150,
    ('surallah', 'tupi'): 150,
    ('tupi', 'koronadal'): 50,
    ('koronadal', 'tupi'): 50,
    ('koronadal', 'banga'): 30,
    ('banga', 'koronadal'): 30,
    ('banga', 'surallah'): 50,
    ('surallah', 'banga'): 50,
    ('tupi', 'general santos'): 120,
    ('general santos', 'tupi'): 120,
    # Add more fixed fares as needed
}

# -------------------- UTILITY FUNCTIONS --------------------
def get_user_coins(username):
    """Retrieve the user's coin balance from the file."""
    try:
        with open(COINS_FILE, 'r') as f:
            user_coins = json.load(f)
            return user_coins.get(username, 100)
    except (json.JSONDecodeError, FileNotFoundError):
        return 100

def update_user_coins(username, new_balance):
    """Update the user's coin balance in the file."""
    try:
        with open(COINS_FILE, 'r') as f:
            user_coins = json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        user_coins = {}
    user_coins[username] = new_balance
    with open(COINS_FILE, 'w') as f:
        json.dump(user_coins, f, indent=4)
    return True

def get_logged_in_username():
    """Get the logged-in username from the session."""
    return session.get('username')

def allowed_file(filename):
    """Check if the file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_payment_requests():
    """Get all payment requests from JSON file"""
    if not os.path.exists(PAYMENTS_FILE):
        with open(PAYMENTS_FILE, 'w') as f:
            json.dump([], f)
        return []
    try:
        with open(PAYMENTS_FILE, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        return []

def save_payment_requests(payments):
    """Save payment requests to JSON file"""
    with open(PAYMENTS_FILE, 'w') as f:
        json.dump(payments, f, indent=4)

def get_user_notifications(username):
    """Get user notifications from JSON file"""
    if not os.path.exists(NOTIFICATIONS_FILE):
        with open(NOTIFICATIONS_FILE, 'w') as f:
            json.dump({}, f)
        return []
    try:
        with open(NOTIFICATIONS_FILE, 'r') as f:
            notifications = json.load(f)
            return notifications.get(username, [])
    except (json.JSONDecodeError, FileNotFoundError):
        return []

def save_user_notification(username, notification):
    """Save a notification for a user"""
    if not os.path.exists(NOTIFICATIONS_FILE):
        notifications = {}
    else:
        try:
            with open(NOTIFICATIONS_FILE, 'r') as f:
                notifications = json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            notifications = {}
    if username not in notifications:
        notifications[username] = []
    notification['created_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    notification['is_read'] = False
    notifications[username].insert(0, notification)
    with open(NOTIFICATIONS_FILE, 'w') as f:
        json.dump(notifications, f, indent=4)

def mark_notification_read(username, index):
    """Mark a specific notification as read."""
    notifications = get_user_notifications(username)
    if 0 <= index < len(notifications):
        notifications[index]['is_read'] = True
        all_notifications = {}
        if os.path.exists(NOTIFICATIONS_FILE):
            with open(NOTIFICATIONS_FILE, 'r') as f:
                all_notifications = json.load(f)
        all_notifications[username] = notifications
        with open(NOTIFICATIONS_FILE, 'w') as f:
            json.dump(all_notifications, f, indent=4)
        return True
    return False

def calculate_fare(origin, destination):
    """Calculates the fare based on origin and destination."""
    origin_lower = origin.lower()
    destination_lower = destination.lower()
    if (origin_lower, destination_lower) in fixed_fares:
        return fixed_fares[(origin_lower, destination_lower)]
    elif (destination_lower, origin_lower) in fixed_fares:
        return fixed_fares[(destination_lower, origin_lower)]
    return None

def generate_random_seat():
    """Generate a random seat number."""
    rows = ['A', 'B', 'C', 'D', 'E']
    numbers = range(1, 7)  # 1-6 seats per row (total 30 seats)
    return f"{random.choice(rows)}{random.choice(numbers)}"

# -------------------- BASIC ROUTES --------------------
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'example' and password == 'password':
            session['username'] = username
            if 'coins' not in session:
                session['coins'] = get_user_coins(username)
            return redirect(url_for('dashboard'))
        else:
            return "Invalid login credentials. Please try again."
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')


@app.route('/track_bus')
def track_bus():
    return render_template('pin_location.html')

# -------------------- SEARCH BUS --------------------
@app.route('/search_bus', methods=['GET', 'POST'])
def search_bus():
    if request.method == 'POST':
        origin = request.form.get('origin', '')
        destination = request.form.get('destination', '')
        search_date = request.form.get('date', '')
        search_time = request.form.get('time', '')
        bus_type_selected = request.form.get('bus_type', '')

        # Get the time display text for recommendations
        time_display = {
            'morning': 'Morning (5 AM - 12 PM)',
            'afternoon': 'Afternoon (12 PM - 5 PM)',
            'evening': 'Evening (5 PM - 10 PM)',
            'night': 'Night (10 PM - 5 AM)',
            '': 'Any Time'
        }.get(search_time, 'Any Time')

        calculated_fare = calculate_fare(origin, destination)
        formatted_fare = f"₱{calculated_fare}" if calculated_fare is not None else "₱N/A"

        matching_buses = []
        for bus in all_buses:
            if (bus['origin'].lower() == origin.lower() and
                    bus['destination'].lower() == destination.lower() and
                    bus['date'] == search_date):

                # Filter by time period if specified
                if search_time == 'morning' and not ('05:00 AM' <= bus['time'] <= '11:59 AM'):
                    continue
                elif search_time == 'afternoon' and not ('12:00 PM' <= bus['time'] <= '04:59 PM'):
                    continue
                elif search_time == 'evening' and not ('05:00 PM' <= bus['time'] <= '09:59 PM'):
                    continue
                elif search_time == 'night' and not (bus['time'] >= '10:00 PM' or bus['time'] <= '04:59 AM'):
                    continue

                # Filter by bus type if specified
                if bus_type_selected and bus['bus_type'] != bus_type_selected:
                    continue

                # Get fare for this route
                fare_value = bus_fares.get((bus['origin'], bus['destination']), 'N/A')
                bus_copy = bus.copy()  # Create a copy to avoid modifying the original
                bus_copy['fare'] = f"₱{fare_value}"  # Single peso sign
                bus_copy['available_seats'] = random.randint(1, 30)  # Add this line here
                bus_copy['seat_number'] = generate_random_seat()  # Random seat number
                matching_buses.append(bus_copy)

        # Limit to top 5 results
        matching_buses = matching_buses[:5]

        recommendations = []
        # Create recommendations based on search criteria
        if not matching_buses:
            # If no matching buses found, create a placeholder recommendation
            recommendations.append({
                'origin': origin,
                'destination': destination,
                'departure': time_display,
                'time': time_display,
                'date': search_date,
                'type': bus_type_selected if bus_type_selected else 'Any',
                'available_seats': random.randint(1, 30),
                'fare': formatted_fare,
                'bus_type': bus_type_selected if bus_type_selected else 'Any'
            })
        else:
            # Create recommendations based on available buses
            for rec_bus_data in random.sample(all_buses, min(5, len(all_buses))):
                if rec_bus_data['origin'].lower() == origin.lower() and rec_bus_data['destination'].lower() == destination.lower() and rec_bus_data['date'] == search_date:
                    rec_bus = rec_bus_data.copy()
                    fare_value = bus_fares.get((rec_bus['origin'], rec_bus['destination']), 'N/A')
                    rec_bus['fare'] = f"₱{fare_value}"  # Single peso sign
                    rec_bus['available_seats'] = random.randint(1, 30)
                    rec_bus['departure'] = time_display
                    rec_bus['time'] = time_display
                    recommendations.append(rec_bus)

        # Ensure we have at least 5 recommendations
        while len(recommendations) < 5:
            recommendations.append({
                'origin': origin,
                'destination': destination,
                'departure': time_display,
                'time': time_display,
                'date': search_date,
                'type': bus_type_selected if bus_type_selected else 'Any',
                'available_seats': random.randint(1, 30),
                'fare': formatted_fare,
                'bus_type': bus_type_selected if bus_type_selected else 'Any'
            })

        # Limit to 5 recommendations
        recommendations = recommendations[:5]

        return render_template('search_bus_results.html',
                               results=matching_buses,
                               recommendations=recommendations,
                               origin=origin,
                               destination=destination,
                               date=search_date,
                               time=search_time,
                               selected_bus_type=bus_type_selected)
    return render_template('search_bus.html')

# -------------------- BOOKING --------------------
@app.route('/book_ticket', methods=['GET'])
def book_ticket():
    return render_template('passenger_details.html')

@app.route('/select_seats', methods=['GET', 'POST'])
def select_seats():
    bus_id = request.args.get('bus_id', '')
    return render_template('select_seats.html', bus_id=bus_id)

# -------------------- TICKET DISPLAY --------------------
@app.route('/bus_ticket/<bus_id>')
def bus_ticket(bus_id):
    bus = next((bus for bus in all_buses if bus['bus_id'] == bus_id), None)
    if bus:
        origin = request.args.get('origin', bus['origin'])
        destination = request.args.get('destination', bus['destination'])
        date = request.args.get('date', bus['date'])
        time = request.args.get('time', bus['time'])
        bus_type = request.args.get('bus_type', bus['bus_type'])
        
        fare = request.args.get('fare')
        if fare is None:
            calculated_fare = calculate_fare(origin, destination)
            if calculated_fare is None:
                fare = "₱N/A"
            else:
                fare = f"₱{calculated_fare}"
        else:
            # Ensure only one peso sign
            fare = f"₱{fare.replace('₱', '')}"

        ticket_data = {
            'ticket_id': f'TKT-{bus_id}-{random.randint(100, 999)}',
            'operator': 'Your Bus Company',
            'origin': origin,
            'destination': destination,
            'date': date,
            'departure_time': time,
            'arrival_time': 'To be determined',
            'bus_id': bus['bus_id'],
            'bus_type': bus_type,
            'plate_number': 'ABC-123' + bus_id[-3:],
            'passenger_name': 'Guest Passenger',
            'seat_number': generate_random_seat(),
            'booking_date': datetime.now().strftime('%Y-%m-%d'),
            'seats_booked': 1,
            'fare': fare,
            'payment_status': 'Pending',
            'available_seats': random.randint(1, 30)
        }
        return render_template('bus_ticket_design.html', ticket=ticket_data)
    else:
        return "Bus details not found."

@app.route('/confirm_ticket')
def confirm_ticket():
    username = get_logged_in_username()
    if not username:
        return redirect(url_for('login'))
    ticket_fare_str = request.args.get('fare', '0')
    try:
        ticket_fare = float(ticket_fare_str.replace('₱', '')) # Remove '₱' for conversion
    except ValueError:
        return "Invalid fare."

    user_coins = get_user_coins(username)
    if user_coins >= ticket_fare:
        new_balance = user_coins - ticket_fare
        if update_user_coins(username, new_balance):
            session['coins'] = new_balance
            return "Ticket booking confirmed and paid with coins!"
        else:
            return "Error updating coin balance. Please try again."
    else:
        return "Insufficient coins to purchase the ticket. Please buy more coins."

# -------------------- PROFILE ROUTES --------------------
@app.route('/profile')
def profile():
    passenger_info = {
        'name': 'JOE QUINSTER DELA CRUS',
        'age': 24,
        'address': 'TUPI SOUTH COTABATO',
        'occupation': 'STUDENT'
    }
    return render_template('profile.html', passenger=passenger_info)

@app.route('/manage_user/<user_id>', methods=['GET', 'POST'])
def manage_user(user_id):
    global passengers_data
    if user_id not in passengers_data:
        return render_template('manage_users.html', user=None, user_id=user_id)
    user = passengers_data[user_id]
    if request.method == 'POST':
        user['name'] = request.form['name']
        user['age'] = request.form['age']
        user['address'] = request.form['address']
        user['occupation'] = request.form['occupation']
        save_passengers(passengers_data)
        flash(f"User '{user['name']}' updated successfully!", 'success')
        return redirect(url_for('manage_user', user_id=user_id))
    return render_template('manage_users.html', user=user, user_id=user_id)

# -------------------- OTHER ROUTES --------------------
@app.route('/help_support')
def help_support():
    return render_template('help_support.html')

@app.route('/admin_dashboard')
def admin_dashboard():
    first_user_id = next(iter(passengers_data), None)
    if first_user_id is None and passengers_data:
        first_user_id = list(passengers_data.keys())[0]
    return render_template('admin_dashboard.html', first_user_id=first_user_id)

@app.route('/add_bus')
def add_bus():
    return render_template('add_bus.html')

@app.route('/tupi_location')
def tupi_location():
    return render_template('tupi_location.html')


@app.route('/reports_analytics')
def reports_analytics():
    return render_template('reports_analytics.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

# -------------------- COINS FEATURE --------------------
@app.route('/my_coins', methods=['GET'])
def my_coins():
    username = session.get('username', 'Guest')
    coins = get_user_coins(username)
    session['coins'] = coins
    notifications = get_user_notifications(username)
    message = session.pop('message', None)
    notification_success = session.pop('notification_success', None)
    notification_error = session.pop('notification_error', None)
    return render_template('my_coins.html', coins=coins, message=message, notifications=notifications, notification_success=notification_success, notification_error=notification_error)

user_coins = {"default_user": 5000}  # initial balance for demo
payments = []  # list of dicts for payment requests

@app.route('/buy_coins', methods=['POST'])
def buy_coins():
    amount = int(request.form['amount'])
    user_coins["default_user"] = user_coins.get("default_user", 0) + amount
    flash(f'Successfully added {amount} coins to your balance.')
    return redirect(url_for('my_coins', success=f'Successfully added {amount} coins.'))

@app.route('/upload_payment', methods=['POST'])
def upload_payment():
    method = request.form.get('method')
    amount = int(request.form.get('amount'))
    screenshot = request.files.get('payment_screenshot')

    if screenshot:
        filename = screenshot.filename
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        screenshot.save(filepath)

        payments.append({
            "id": len(payments)+1,
            "user": "default_user",
            "date": datetime.now().strftime("%Y-%m-%d"),
            "time": datetime.now().strftime("%I:%M %p"),
            "amount": amount,
            "method": method,
            "status": "Pending",
            "screenshot": filename
        })

        return jsonify({"success": True, "message": "Thank you! Your payment request is now being processed."})
    else:
        return jsonify({"success": False, "error": "No screenshot uploaded."})

@app.route('/admin/coins_payment')
def admin_coins_payment():
    return render_template('coins_payment.html', payments=payments)

@app.route('/confirm_payment', methods=['POST'])
def confirm_payment():
    payment_id = int(request.form['payment_id'])
    action = request.form['action']

    for payment in payments:
        if payment['id'] == payment_id:
            if action == 'confirm':
                payment['status'] = 'Confirmed'
                user_coins[payment['user']] = user_coins.get(payment['user'], 0) + payment['amount']
                flash(f"Payment #{payment_id} confirmed, {payment['amount']} coins added.")
            elif action == 'reject':
                payment['status'] = 'Rejected'
                flash(f"Payment #{payment_id} rejected.")
            break

    return redirect(url_for('admin_coins_payment'))

@app.route('/coins_payment')
def coins_payment():
    pending_payments = [p for p in payments if p.get('status', 'Pending') == 'Pending']
    return render_template('coins_payment.html', payments=pending_payments)

@app.route('/confirm_ticket_payment', methods=['POST'])
def confirm_ticket_payment():
    username = get_logged_in_username()
    if not username:
        flash('You must be logged in to pay with coins.', 'error')
        return redirect(url_for('login'))

    if 'current_ticket' not in session:
        flash('No ticket information found.', 'error')
        return redirect(url_for('search_bus'))

    ticket = session['current_ticket']
    fare_value = float(ticket['fare'].replace('₱', '')) # Extract fare as float
    user_coins = get_user_coins(username)

    if user_coins >= fare_value:
        new_balance = user_coins - fare_value
        if update_user_coins(username, new_balance):
            session['coins'] = new_balance
            ticket['payment_status'] = 'Paid'
            # In a real application, you would save the 'ticket' data permanently here
            # For this example, we'll just update the session.
            session['current_ticket'] = ticket
            flash('Ticket purchased successfully with coins!', 'success')
            # Add notification for successful purchase
            notification = {
                'type': 'success',
                'message': f"🎫 You have successfully purchased a ticket from {ticket['origin']} to {ticket['destination']} for {ticket['fare']}.",
                'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'is_read': False
            }
            save_user_notification(username, notification)
            return redirect(url_for('my_tickets')) # Redirect to a page showing user's tickets
        else:
            flash('Error updating coin balance. Please try again.', 'error')
            return redirect(url_for('ticket_confirmation'))
    else:
        flash('Insufficient coins to purchase the ticket.', 'error')
        return redirect(url_for('ticket_confirmation'))

@app.route('/get_user_coins', methods=['GET'])
def get_user_coins_api():
    username = session.get('username')
    if not username:
        return jsonify({'error': 'Not logged in'}), 401
    return jsonify({'coins': get_user_coins(username)})

@app.route('/process_payment', methods=['POST'])
def process_payment():
    """Process payment approval or rejection by admin"""
    payment_id = request.form.get('payment_id')
    action = request.form.get('action')
    
    if not payment_id or not action:
        return jsonify({'success': False, 'error': 'Missing payment ID or action'}), 400
    
    try:
        payment_id = int(payment_id)
    except ValueError:
        return jsonify({'success': False, 'error': 'Invalid payment ID'}), 400
        
    payments = get_payment_requests()
    payment = None
    
    # Find the payment by ID
    for p in payments:
        if p.get('id') == payment_id:
            payment = p
            break
    
    if not payment:
        return jsonify({'success': False, 'error': 'Payment not found'}), 404
    
    # Update payment status
    if action == 'approve':
        payment['status'] = 'Approved'
        
        # Update user's coin balance
        username = payment['user']
        amount = payment['amount']
        current_balance = get_user_coins(username)
        new_balance = current_balance + amount
        update_user_coins(username, new_balance)
        
        # Add notification for the user
        save_user_notification(username, {
            'type': 'success',
            'message': f"Your payment of {amount} coins has been approved!"
        })
        
        message = f"Payment #{payment_id} approved. {amount} coins added to {username}'s balance."
    elif action == 'reject':
        payment['status'] = 'Rejected'
        
        # Add notification for the user
        username = payment['user']
        save_user_notification(username, {
            'type': 'error',
            'message': f"Your payment request for {payment['amount']} coins was rejected."
        })
        
        message = f"Payment #{payment_id} rejected."
    else:
        return jsonify({'success': False, 'error': 'Invalid action'}), 400
    
    # Save updated payments
    save_payment_requests(payments)
    
    return jsonify({
        'success': True, 
        'message': message,
        'payment_id': payment_id,
        'status': payment['status'],
        'user': payment['user'],
        'amount': payment['amount']
    })

@app.route('/payment_status_sse')
def payment_status_sse():
    """Server-Sent Events endpoint for real-time payment status updates"""
    def generate():
        username = get_logged_in_username()
        if not username:
            yield "data: {\"error\": \"Not logged in\"}\n\n"
            return
            
        # Initial connection message
        yield "data: {\"connected\": true}\n\n"
        
        # Check for notifications
        notifications = get_user_notifications(username)
        for notification in notifications:
            if not notification.get('is_read', False):
                # Mark as read
                notification['is_read'] = True
                
                # Send notification about payment status
                if "approved" in notification.get('message', '').lower():
                    coins = get_user_coins(username)
                    yield f"data: {{\"status\": \"approved\", \"new_balance\": {coins}}}\n\n"
                elif "rejected" in notification.get('message', '').lower():
                    yield "data: {\"status\": \"rejected\"}\n\n"
        
        # Update notifications
        all_notifications = {}
        if os.path.exists(NOTIFICATIONS_FILE):
            with open(NOTIFICATIONS_FILE, 'r') as f:
                all_notifications = json.load(f)
        all_notifications[username] = notifications
        with open(NOTIFICATIONS_FILE, 'w') as f:
            json.dump(all_notifications, f, indent=4)
        
    return Response(generate(), mimetype='text/event-stream')

@app.route('/check_new_payments')
def check_new_payments():
    """API endpoint for admin to check for new payments"""
    # This would be more sophisticated in a production app
    # For now, just return all pending payments
    payments = get_payment_requests()
    pending_payments = [p for p in payments if p.get('status', 'Pending') == 'Pending']
    return jsonify({'new_payments': pending_payments})

# -------------------- GET DIRECTIONS --------------------
@app.route('/get_directions', methods=['POST'])
def get_directions():
    start = request.form.get('start')
    end = request.form.get('end')
    use_shortcut = request.form.get('shortcut') == 'on'
    return render_template('tupi_location.html', start=start, end=end, use_shortcut=use_shortcut)

@app.route('/manage_routes')
def manage_routes():
    return render_template('manage_routes.html')

@app.route('/update_bus_status')
def update_bus_status():
    return render_template('update_bus_status.html')

# -------------------- NOTIFICATIONS API --------------------
@app.route('/mark_notification_read/<int:index>', methods=['POST'])
def mark_notification_read_api(index):
    username = get_logged_in_username()
    if not username:
        return jsonify({'error': 'Not logged in'}), 401
    success = mark_notification_read(username, index)
    if success:
        return jsonify({'success': True})
    return jsonify({'error': 'Notification not found'}), 404

# -------------------- TICKET CONFIRMATION --------------------
@app.route('/ticket_confirmation', methods=['GET', 'POST'])
def ticket_confirmation():
    if request.method == 'POST':
        # Process ticket purchase data from the form
        bus_id = request.form.get('bus_id')
        origin = request.form.get('origin')
        destination = request.form.get('destination')
        date = request.form.get('date')
        time = request.form.get('time')
        bus_type = request.form.get('bus_type')
        fare_str = request.form.get('fare', '0')
        available_seats = request.form.get('available_seats', '0')

        try:
            fare_value = float(fare_str.replace('₱', ''))
        except ValueError:
            flash('Invalid fare.', 'danger')
            return redirect(url_for('search_bus'))

        # Generate a unique ticket ID
        ticket_id = f'TKT-{bus_id}-{random.randint(1000, 9999)}'

        # Assign a random seat number
        seat_number = generate_random_seat()

        # Create ticket data dictionary
        ticket_data = {
            'ticket_id': ticket_id,
            'operator': 'Your Bus Company',
            'origin': origin,
            'destination': destination,
            'date': date,
            'departure_time': time,
            'arrival_time': 'To be determined',
            'bus_id': bus_id,
            'bus_type': bus_type,
            'plate_number': f'ABC-{random.randint(100, 999)}',
            'passenger_name': session.get('username', 'Guest Passenger'),
            'seat_number': seat_number,
            'booking_date': datetime.now().strftime('%Y-%m-%d'),
            'seats_booked': 1,
            'fare': f"₱{fare_value:.2f}", # Store as float for calculation, display formatted
            'payment_status': 'Pending', # Initial status
            'available_seats': available_seats
        }

        session['current_ticket'] = ticket_data
        username = get_logged_in_username()
        current_balance = get_user_coins(username) if username else 0
        return render_template('ticket_confirmation.html', ticket=ticket_data, current_balance=current_balance)

    else:
        ticket_data = session.get('current_ticket')
        if ticket_data:
            username = get_logged_in_username()
            current_balance = get_user_coins(username) if username else 0
            return render_template('ticket_confirmation.html', ticket=ticket_data, current_balance=current_balance)
        else:
            flash('No ticket details found. Please search for a bus again.', 'warning')
            return redirect(url_for('search_bus'))


@app.route('/buy_ticket', methods=['POST'])
def buy_ticket():
    # Get ticket details from form
    bus_id = request.form.get('bus_id')
    origin = request.form.get('origin')
    destination = request.form.get('destination')
    date = request.form.get('date')
    time = request.form.get('time')
    bus_type = request.form.get('bus_type')
    fare = request.form.get('fare')
    available_seats = request.form.get('available_seats', random.randint(1, 30))
    
    # Redirect to ticket confirmation with the ticket details
    return render_template('ticket_confirmation.html', 
                          bus_id=bus_id,
                          origin=origin,
                          destination=destination,
                          date=date,
                          time=time,
                          bus_type=bus_type,
                          fare=fare,
                          available_seats=available_seats)

@app.route('/update_coin_request', methods=['POST'])
def update_coin_request():
    data = request.get_json()
    req_id = data['request_id']
    user_id = data['user_id']
    amount = data['amount']
    action = data['action']

    conn = mysql.connect()
    cursor = conn.cursor()

    if action == 'approve':
        # Update user coins
        cursor.execute("UPDATE users SET coins = coins + %s WHERE id = %s", (amount, user_id))
        msg = f"Your request to buy {amount} coins has been approved!"
    else:
        msg = "Your request to buy coins has been rejected."

    # Insert into notifications
    cursor.execute("INSERT INTO notifications (user_id, message) VALUES (%s, %s)", (user_id, msg))

    # Remove the coin request (no matter what)
    cursor.execute("DELETE FROM coin_requests WHERE id = %s", (req_id,))

    conn.commit()
    cursor.close()
    conn.close()

    return jsonify({'success': True, 'message': msg})

# -------------------- ADDITIONAL UTILITY ROUTES --------------------
@app.route('/get_available_seats/<bus_id>')
def get_available_seats(bus_id):
    """API endpoint to get available seats for a bus"""
    # In a real app, this would query a database
    # For now, generate random number of available seats
    available_seats = random.randint(1, 30)
    return jsonify({'available_seats': available_seats})

@app.route('/get_bus_types')
def get_bus_types():
    """API endpoint to get all bus types"""
    bus_types = ["Non-stop", "Regular"]
    return jsonify({'bus_types': bus_types})

# -------------------- ERROR HANDLERS --------------------
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500

# Run the app
if __name__ == '__main__':
    app.run(debug=True)