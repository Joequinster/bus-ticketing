// Initialize Leaflet map
const map = L.map('map').setView([6.3654, 124.9527], 13); // Centered on Tupi

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
}).addTo(map);

// Add bus icon
var busIcon = L.icon({
    iconUrl: 'https://img.icons8.com/ios/200/msePX8GvIuji/bus--v1.png',
    iconSize: [50, 50],       // Adjust size as needed
    iconAnchor: [25, 25],     // Icon center
    popupAnchor: [0, -25]     // Popup position relative to icon
});

// Function to fetch route and display it
async function getRoute(from, to) {
    const res = await fetch(`https://router.project-osrm.org/route/v1/driving/${from};${to}?overview=full&geometries=geojson`);
    const data = await res.json();

    if (data.routes.length > 0) {
        const route = data.routes[0].geometry.coordinates;
        const latlngs = route.map(coord => [coord[1], coord[0]]);
        L.polyline(latlngs, { color: 'blue' }).addTo(map);

        const busMarker = L.marker(latlngs[0], { icon: busIcon }).addTo(map);
        let i = 0;
        const interval = setInterval(() => {
            if (i >= latlngs.length) {
                clearInterval(interval);
                return;
            }
            busMarker.setLatLng(latlngs[i]);
            i++;
        }, 200);
    } else {
        alert('Route not found.');
    }
}

// Handle form submission
document.getElementById('routeForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const from = document.getElementById('from').value;
    const to = document.getElementById('to').value;

    // Hardcoded locations, change or add more as needed
    const locations = {
        'tupi': [124.9527, 6.3654],
        'koronadal': [124.8469, 6.5000]
    };

    if (locations[from.toLowerCase()] && locations[to.toLowerCase()]) {
        getRoute(locations[from.toLowerCase()].join(','), locations[to.toLowerCase()].join(','));
    } else {
        alert('Invalid locations. Use "Tupi" or "Koronadal".');
    }
});
