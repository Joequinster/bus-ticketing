// Initialize Google Maps
let map;
let markers = [];
let busInfoContainer = document.getElementById('busInfo');

function initMap() {
    const mapOptions = {
        center: { lat: 6.4333, lng: 124.8333 }, // Center on South Cotabato
        zoom: 10,
    };
    map = new google.maps.Map(document.getElementById("map"), mapOptions);

    // Add terminal locations as markers
    const locations = [
        { name: "Tupi Terminal", lat: 6.4333, lng: 124.8333 },
        { name: "Koronadal Terminal", lat: 6.5085, lng: 124.7387 },
        { name: "General Santos Terminal", lat: 6.1167, lng: 125.1794 },
    ];

    locations.forEach(location => {
        const marker = new google.maps.Marker({
            position: { lat: location.lat, lng: location.lng },
            map: map,
            title: location.name,
        });

        marker.addListener("click", () => {
            showBusInfo(location.name);
        });

        markers.push(marker);
    });
}

// Function to display bus information based on the terminal clicked
function showBusInfo(location) {
    const busData = {
        "Tupi Terminal": [
            {
                name: 'Tupi Bus 1',
                status: 'waiting',
                route: 'Tupi → Koronadal',
                departureTime: '08:00 AM',
                availableSeats: 10,
                fare: '₱150.00'
            },
            {
                name: 'Tupi Bus 2',
                status: 'traveling',
                route: 'Tupi → Davao',
                departureTime: '09:00 AM',
                availableSeats: 5,
                fare: '₱200.00'
            }
        ],
        "Koronadal Terminal": [
            {
                name: 'Koronadal Bus 1',
                status: 'not available',
                route: 'Koronadal → Tupi',
                departureTime: '10:00 AM',
                availableSeats: 0,
                fare: '₱180.00'
            }
        ]
    };

    const buses = busData[location] || [];

    busInfoContainer.innerHTML = `<h2>Buses Available in ${location}</h2>`;
    
    if (buses.length === 0) {
        busInfoContainer.innerHTML += "<p>No buses available at this location.</p>";
        return;
    }

    buses.forEach(bus => {
        const busInfo = document.createElement('div');
        busInfo.classList.add('bus-info');
        busInfo.innerHTML = `
            <div class="status">${getBusStatus(bus.status)}</div>
            <div class="details">
                <p><strong>Bus Name:</strong> ${bus.name}</p>
                <p><strong>Route:</strong> ${bus.route}</p>
                <p><strong>Departure Time:</strong> ${bus.departureTime}</p>
                <p><strong>Available Seats:</strong> ${bus.availableSeats}</p>
                <p><strong>Fare:</strong> ${bus.fare}</p>
            </div>
        `;
        busInfoContainer.appendChild(busInfo);
    });
}

// Function to return the bus status icon and text
function getBusStatus(status) {
    switch (status) {
        case 'waiting': return '<span style="color: green;">🟢 Waiting</span>';
        case 'traveling': return '<span style="color: blue;">🔵 Traveling</span>';
        case 'not available': return '<span style="color: red;">🔴 Not Available</span>';
        default: return '';
    }
}

// Function to handle bus search
function searchBus() {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const busInfoContainer = document.getElementById('busInfo');
    
    // Clear any previous bus info
    busInfoContainer.innerHTML = '';

    // Placeholder for bus data
    const buses = [
        {
            name: 'Tupi Bus 1',
            status: 'waiting',
            route: 'Tupi → Koronadal',
            departureTime: '08:00 AM',
            availableSeats: 10,
            fare: '₱150.00'
        },
        {
            name: 'Tupi Bus 2',
            status: 'traveling',
            route: 'Tupi → Davao',
            departureTime: '09:00 AM',
            availableSeats: 5,
            fare: '₱200.00'
        },
        {
            name: 'Tupi Bus 3',
            status: 'not available',
            route: 'Tupi → General Santos',
            departureTime: '10:00 AM',
            availableSeats: 0,
            fare: '₱180.00'
        }
    ];

    // Filter buses by search input
    const filteredBuses = buses.filter(bus => bus.route.toLowerCase().includes(searchInput));

    // Display filtered buses
    if (filteredBuses.length > 0) {
        filteredBuses.forEach(bus => {
            const busInfo = document.createElement('div');
            busInfo.classList.add('bus-info');
            busInfo.innerHTML = `
                <div class="status">${getBusStatus(bus.status)}</div>
                <div class="details">
                    <p><strong>Bus Name:</strong> ${bus.name}</p>
                    <p><strong>Route:</strong> ${bus.route}</p>
                    <p><strong>Departure Time:</strong> ${bus.departureTime}</p>
                    <p><strong>Available Seats:</strong> ${bus.availableSeats}</p>
                    <p><strong>Fare:</strong> ${bus.fare}</p>
                </div>
            `;
            busInfoContainer.appendChild(busInfo);
        });
    } else {
        busInfoContainer.innerHTML = "<p>No buses found for the given search criteria.</p>";
    }
}
